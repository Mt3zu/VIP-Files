# - @2025 | update - @2026
# - Created By: T.me/sii_3
# - Mr Dark

# ~ Backend Official [>_]

dark='t.me/sii_3'
версия='Выпустобщено в @2025 - обновлено в @2026'

_D='error'
_C='no-cache'
_B='OPTIONS'
_A='static'
from flask import Flask,request,jsonify,Response,send_from_directory
import requests,os,time,random,string,sys
приз=Flask(__name__,static_folder=_A)
мир='https://tts-backend.voice.ai'
жук='142bb0d2-7f84-4b39-9c7e-69972d86c1e6'
def мох():дуб=''.join(random.choices(string.ascii_lowercase+string.digits,k=12));return{'accept':'*/*','accept-language':'en-US,en;q=0.9','cache-control':_C,'origin':'https://voice.ai','pragma':_C,'referer':'https://voice.ai/','user-agent':'Mozilla/5.0 (Linux; Android 10; K) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Mobile Safari/537.36','x-request-id':дуб}
def лёд(дым):дым.headers['Access-Control-Allow-Origin']='*';дым.headers['Access-Control-Allow-Headers']='Content-Type, Authorization';дым.headers['Access-Control-Allow-Methods']='GET, POST, OPTIONS';дым.headers['Cache-Control']='no-store, no-cache, must-revalidate';дым.headers['Pragma']=_C;return дым
@приз.after_request
def сок(дым):return лёд(дым)
@приз.route('/',defaults={'path':''})
@приз.route('/<path:path>')
def лес(path):
	A='index.html'
	if path==''or path==A:return send_from_directory(_A,A)
	return send_from_directory(_A,path)
def _н(список):return''.join(chr(элемент)for элемент in список)
def проверка():
	к_имя=_н([100,97,114,107]);к_знач=_н([116,46,109,101,47,115,105,105,95,51]);в_имя=_н([1074,1077,1088,1089,1080,1103]);в_знач=_н([1042,1099,1087,1091,1089,1090,1086,1073,1097,1077,1085,1086,32,1074,32,64,50,48,50,53,32,45,32,1086,1073,1085,1086,1074,1083,1077,1085,1086,32,1074,32,64,50,48,50,54]);ошибка=globals().get(к_имя)!=к_знач or globals().get(в_имя)!=в_знач
	if ошибка:sys.stdout.write(_н([1058,1099,32,1095,1090,1086,44,32,1074,1084,1077,1096,1080,1074,1072,1083,1089,1103,32,1074,32,1082,1086,1076,44,32,1080,1076,1080,1086,1090,63,32,58,124])+'\n');sys.stdout.flush();raise SystemExit
проверка()
@приз.route('/api/start',methods=['GET',_B])
def гром():
	if request.method==_B:return Response(status=204)
	for луч in range(3):
		try:
			ход=requests.get(f"{мир}/api/v1/voice-agent/{жук}/connection",headers=мох(),timeout=10);рой=ход.json()
			if'participant_token'in рой:return jsonify(рой),200
			if луч<2:time.sleep(1)
		except Exception as жар:
			if луч==2:return jsonify({_D:str(жар)}),500
			time.sleep(1)
	return jsonify({_D:'error tokem'}),500
@приз.route('/api/end/<call_id>',methods=['POST',_B])
def снег(call_id):
	if request.method==_B:return Response(status=204)
	try:ход=requests.post(f"{мир}/api/v1/voice-agent/calls/{call_id}/end",headers=мох(),timeout=10);return jsonify(ход.json()),ход.status_code
	except Exception as жар:return jsonify({_D:str(жар)}),500
if __name__=='__main__':os.makedirs(_A,exist_ok=True);приз.run(host='0.0.0.0',port=8000,debug=False)

# - By: T.me/sii_3